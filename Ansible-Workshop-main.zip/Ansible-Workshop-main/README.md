# Ansible-Workshop

For ansible workshop scenario
